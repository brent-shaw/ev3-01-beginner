from flask import render_template
from app import app
import collections

#------------------------------------------------------------------------------
#Dictionary for storing pages and clues
#Now using OrderedDict

#This should become its own handler

pages = collections.OrderedDict()
pages['1'] = '1'
pages['2'] ='two'
pages['three'] = 'iii'
pages['iv'] = '4444'
pages['55555'] = 'eevviiff'
pages['xxiiss'] = 'sat'
pages['sun'] = 'sept'
pages['huit'] = 'neptune'
pages['pluto'] = 'nueve'
pages['diez'] = 'tenth card'
pages['jack'] = 'eLeVeN'
pages['tWeLvE'] = '144'
pages['169'] = 'number13'
pages['number14'] = '49 52'
pages['49 53'] = 'quindecim'
pages['sedecim'] = 'sechzehn'
pages['siebzehn'] = '10001'
pages['10010'] = 'rvtugrra'
pages['avargrra'] = 'K'
pages['Ca'] = 'icosagon'
pages['icosihenagon'] = '10946'
pages['17711'] = 'MngyMi0yMg=='
pages['MngyMy0yMw=='] = '&#87;'
pages['&#88;'] = '..--- ....-'
pages['..--- .....'] = 'yy-yyyyy'
pages['zz-zzzzzz'] = 'Congratulations! You completed the challenge'
pages['lol'] = "You found the hidden treasure!"

#------------------------------------------------------------------------------
#Function for displaying the start page

@app.route('/')
def start():
    return render_template("index.html", clue="Welcome!")

#------------------------------------------------------------------------------
#Function for returning each clue page / puzzle page
#Takes the page name and looks up clue in Pages Dictionary

@app.route('/<T>')
def puzzle(T):
    try:
        n = pages.keys().index(T)+1;
        return render_template("puzzle.html", number=n, clue=pages[T])
    except:
        return render_template("puzzle.html", clue='Nope, Try again!'), 400

#------------------------------------------------------------------------------
